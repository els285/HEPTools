# HEPTools

A collection of tools for high-energy particle physics analyses.

**Crucial: Requires a ROOT build for the python type being used. I only have ROOT built for Python3.6**
